Lyra Music Android Studio project (source, not a compiled APK)

Build an APK:
1. Install Android Studio on Windows/Mac/Linux.
2. Extract this ZIP.
3. In Android Studio choose Open and select the LyraMusic folder.
4. Allow Gradle sync/downloads to complete.
5. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Find the generated APK from the notification's "locate" link, usually app/build/outputs/apk/debug/app-debug.apk.
7. Transfer the APK to your Android phone and install it. You may need to allow installation from that source.

Features included: local audio selection through the app's file picker, playback controls, .lrc lyric import, timestamp-synced highlighting/scrolling, and manual lyric offset.

Limitations: this is a WebView wrapper around the starter player, not a fully native audio engine. Background playback and lock-screen/media notification controls are not implemented in this initial APK project. The APK is not precompiled in this ZIP.

BUILD APK WITH GITHUB ACTIONS (no Android Studio required):
1. Create a new repository on https://github.com/new (public or private).
2. Upload all contents of this project ZIP into the repository root. Make sure .github/workflows/android-apk.yml is included.
3. Commit the files to the main branch.
4. Open the repository's Actions tab. Choose "Build Lyra Music APK" and click "Run workflow" if it has not started automatically.
5. Wait for the run to finish green. Open the completed run and download the "Lyra-Music-debug-APK" artifact.
6. Extract the downloaded artifact ZIP to get app-debug.apk, then transfer it to your Android phone and install.

The workflow builds an unsigned-by-you debug APK suitable for testing; it is not a Play Store release.
