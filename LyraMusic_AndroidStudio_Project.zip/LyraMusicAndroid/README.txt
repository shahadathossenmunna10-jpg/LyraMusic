Lyra Music Android Studio project (source, not a compiled APK)

Build an APK:
1. Install Android Studio on Windows/Mac/Linux.
2. Extract this ZIP.
3. In Android Studio choose Open and select the LyraMusic folder.
4. Allow Gradle sync/downloads to complete.
5. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Find the generated APK from the notification's "locate" link, usually app/build/outputs/apk/debug/app-debug.apk.
7. Transfer the APK to your Android phone and install it. You may need to allow installation from that source.

Features included: local audio selection through the app's file picker, playback controls, .lrc lyric import, timestamp-synced highlighting/scrolling, and manual lyric offset.

Limitations: this is a WebView wrapper around the starter player, not a fully native audio engine. Background playback and lock-screen/media notification controls are not implemented in this initial APK project. The APK is not precompiled in this ZIP.
